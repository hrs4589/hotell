<?php
/**
 * Database connection configuration
 * Using PDO for database connection
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define database connection constants based on environment variables for compatibility with various hosts
// We check for PostgreSQL first (for Replit), then MySQL if unavailable
if (isset($_ENV['PGHOST']) && isset($_ENV['PGDATABASE']) && isset($_ENV['PGUSER']) && isset($_ENV['PGPASSWORD'])) {
    define('DB_HOST', $_ENV['PGHOST']);
    define('DB_NAME', $_ENV['PGDATABASE']);
    define('DB_USER', $_ENV['PGUSER']);
    define('DB_PASS', $_ENV['PGPASSWORD']);
    define('DB_PORT', $_ENV['PGPORT'] ?? '5432');
    define('DB_CHARSET', 'utf8');
    define('DB_TYPE', 'pgsql');
} else {
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'hotel_management');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_CHARSET', 'utf8mb4');
    define('DB_TYPE', 'mysql');
}

// Create PDO connection
try {
    if (DB_TYPE === 'pgsql') {
        $dsn = "pgsql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME;
    } else {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    }
    
    $pdo = new PDO(
        $dsn,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    // Handle connection error
    die("Database Connection Error: " . $e->getMessage());
}
