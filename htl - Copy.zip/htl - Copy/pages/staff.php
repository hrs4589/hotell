<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole('Manajer')) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You do not have permission to access this page.</div></div>';
    exit;
}

// Process form submissions
$success = $error = '';

// Process add/edit staff
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Common form data
    $username = sanitize($_POST['username']);
    $nama_lengkap = sanitize($_POST['nama_lengkap']);
    $role = sanitize($_POST['role']);
    
    // Validate form data
    if (empty($username) || empty($nama_lengkap) || empty($role)) {
        $error = 'Username, nama lengkap, dan role harus diisi';
    } else {
        try {
            if ($action === 'add') {
                $password = $_POST['password'];
                if (empty($password)) {
                    $error = 'Password harus diisi untuk staff baru';
                } else {
                    // Check if username already exists
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM staff WHERE username = ?");
                    $stmt->execute([$username]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'Username sudah digunakan';
                    } else {
                        // Hash password
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        
                        // Insert new staff
                        $stmt = $pdo->prepare("
                            INSERT INTO staff (username, password, nama_lengkap, role, last_login)
                            VALUES (?, ?, ?, ?, NULL)
                        ");
                        $stmt->execute([$username, $hashed_password, $nama_lengkap, $role]);
                        $success = 'Staff berhasil ditambahkan';
                    }
                }
            } elseif ($action === 'edit' && isset($_POST['id_staff'])) {
                $id_staff = (int)$_POST['id_staff'];
                
                // Check if staff exists
                $stmt = $pdo->prepare("SELECT * FROM staff WHERE id_staff = ?");
                $stmt->execute([$id_staff]);
                $staff = $stmt->fetch();
                
                if (!$staff) {
                    $error = 'Staff tidak ditemukan';
                } else {
                    // Check if username already exists for another staff
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM staff WHERE username = ? AND id_staff != ?");
                    $stmt->execute([$username, $id_staff]);
                    if ($stmt->fetchColumn() > 0) {
                        $error = 'Username sudah digunakan oleh staff lain';
                    } else {
                        // Update staff data
                        $stmt = $pdo->prepare("
                            UPDATE staff 
                            SET username = ?, nama_lengkap = ?, role = ?
                            WHERE id_staff = ?
                        ");
                        $stmt->execute([$username, $nama_lengkap, $role, $id_staff]);
                        
                        // Update password if provided
                        if (!empty($_POST['password'])) {
                            $new_password = $_POST['password'];
                            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                            
                            $stmt = $pdo->prepare("UPDATE staff SET password = ? WHERE id_staff = ?");
                            $stmt->execute([$hashed_password, $id_staff]);
                        }
                        
                        $success = 'Data staff berhasil diperbarui';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Process delete staff
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_staff = (int)$_GET['id'];
    
    try {
        // Check if the staff exists
        $stmt = $pdo->prepare("SELECT * FROM staff WHERE id_staff = ?");
        $stmt->execute([$id_staff]);
        $staff = $stmt->fetch();
        
        if (!$staff) {
            $error = 'Staff tidak ditemukan';
        } else {
            // Prevent deleting yourself
            if ($id_staff == $_SESSION['staff_id']) {
                $error = 'Anda tidak dapat menghapus akun yang sedang digunakan';
            } else {
                // Delete the staff
                $stmt = $pdo->prepare("DELETE FROM staff WHERE id_staff = ?");
                $stmt->execute([$id_staff]);
                $success = 'Staff berhasil dihapus';
            }
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Get all staff
try {
    $stmt = $pdo->query("SELECT * FROM staff ORDER BY nama_lengkap");
    $staffList = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $staffList = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Staff Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStaffModal">
            <i class="fas fa-plus"></i> Add New Staff
        </button>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Staff List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Staff</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Role</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($staffList)): ?>
                        <tr>
                            <td colspan="6" class="text-center">No staff found</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($staffList as $staff): ?>
                            <tr>
                                <td><?= $staff['id_staff'] ?></td>
                                <td><?= $staff['username'] ?></td>
                                <td><?= $staff['nama_lengkap'] ?></td>
                                <td><?= $staff['role'] ?></td>
                                <td><?= $staff['last_login'] ? date('d/m/Y H:i', strtotime($staff['last_login'])) : 'Never' ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editStaffModal"
                                            data-id="<?= $staff['id_staff'] ?>"
                                            data-username="<?= $staff['username'] ?>"
                                            data-nama="<?= $staff['nama_lengkap'] ?>"
                                            data-role="<?= $staff['role'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <?php if ($staff['id_staff'] != $_SESSION['staff_id']): ?>
                                    <a href="index.php?page=staff&action=delete&id=<?= $staff['id_staff'] ?>" class="btn btn-sm btn-danger btn-delete" onclick="return confirm('Are you sure you want to delete this staff?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<!-- Add Staff Modal -->
<div class="modal fade" id="addStaffModal" tabindex="-1" aria-labelledby="addStaffModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addStaffModalLabel">Add New Staff</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="nama_lengkap" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-control" id="role" name="role" required>
                            <?php foreach (getStaffRoles() as $role): ?>
                            <option value="<?= $role ?>"><?= $role ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Staff Modal -->
<div class="modal fade" id="editStaffModal" tabindex="-1" aria-labelledby="editStaffModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editStaffModalLabel">Edit Staff</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id_staff" id="edit_id_staff">
                    
                    <div class="mb-3">
                        <label for="edit_username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="edit_username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="edit_password" name="password">
                        <small class="form-text text-muted">Leave empty to keep current password</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_nama_lengkap" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="edit_nama_lengkap" name="nama_lengkap" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_role" class="form-label">Role</label>
                        <select class="form-control" id="edit_role" name="role" required>
                            <?php foreach (getStaffRoles() as $role): ?>
                            <option value="<?= $role ?>"><?= $role ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle edit staff button clicks
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get staff data from button attributes
            const staffId = this.dataset.id;
            const username = this.dataset.username;
            const nama = this.dataset.nama;
            const role = this.dataset.role;
            
            // Fill form fields with staff data
            document.getElementById('edit_id_staff').value = staffId;
            document.getElementById('edit_username').value = username;
            document.getElementById('edit_nama_lengkap').value = nama;
            document.getElementById('edit_role').value = role;
            // Clear password field
            document.getElementById('edit_password').value = '';
        });
    });
});
</script>
