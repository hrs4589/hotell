<?php
/**
 * Session management for the hotel management system
 */

// Start the session
session_start();

// Set session parameters for security
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_secure', 0); // Set to 1 if using HTTPS

// Set session timeout to 30 minutes of inactivity
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    // Last request was more than 30 minutes ago
    session_unset();     // unset $_SESSION variable for the run-time
    session_destroy();   // destroy session data in storage
}
$_SESSION['LAST_ACTIVITY'] = time(); // update last activity time stamp

// Regenerate session ID every 30 minutes to prevent session fixation attacks
if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} else if (time() - $_SESSION['CREATED'] > 1800) {
    // Session started more than 30 minutes ago
    session_regenerate_id(true);    // change session ID for the current session and invalidate old session ID
    $_SESSION['CREATED'] = time();  // update creation time
}

// Function to set user session
function setUserSession($user_data, $is_staff = true) {
    if ($is_staff) {
        $_SESSION['user_id'] = $user_data['id_staff'];
        $_SESSION['username'] = $user_data['username'];
        $_SESSION['nama_lengkap'] = $user_data['nama_lengkap'];
        $_SESSION['user_role'] = $user_data['role'];
        $_SESSION['user_type'] = 'staff';
    } else {
        $_SESSION['user_id'] = $user_data['id_tamu'];
        $_SESSION['username'] = $user_data['username'];
        $_SESSION['nama_lengkap'] = $user_data['nama_lengkap'];
        $_SESSION['user_role'] = 'Tamu';
        $_SESSION['user_type'] = 'tamu';
    }
    
    // Set a random token for CSRF protection
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

// Function to clear user session
function clearUserSession() {
    session_unset();
    session_destroy();
}

// Function to get CSRF token
function getCsrfToken() {
    return $_SESSION['csrf_token'] ?? '';
}

// Function to verify CSRF token
function verifyCsrfToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        return false;
    }
    return true;
}

// Function to check if current user is staff
function isStaff() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'staff';
}

// Function to check if current user is tamu/guest
function isTamu() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'tamu';
}
?>
