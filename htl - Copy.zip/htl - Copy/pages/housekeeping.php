<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole(['Housekeeping'])) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You do not have permission to access this page.</div></div>';
    exit;
}

// Process form submissions
$success = $error = '';

// Process update room status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'update_status') {
        $id_kamar = isset($_POST['id_kamar']) ? (int)$_POST['id_kamar'] : 0;
        $status = sanitize($_POST['status']);
        $maintenance_notes = sanitize($_POST['maintenance_notes'] ?? '');
        $current_status = sanitize($_POST['current_status'] ?? '');
        
        // Validate form data
        if ($id_kamar <= 0 || empty($status)) {
            $error = 'Room ID and status are required';
        } else {
            try {
                // Update room status and maintenance notes
                if ($status === 'Maintenance') {
                    if (!empty($maintenance_notes)) {
                        $stmt = $pdo->prepare("UPDATE kamar SET status = ?, note = ? WHERE id_kamar = ?");
                        $stmt->execute([$status, $maintenance_notes, $id_kamar]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE kamar SET status = ? WHERE id_kamar = ?");
                        $stmt->execute([$status, $id_kamar]);
                    }
                } else {
                    // Clear maintenance notes when status changes from Maintenance
                    if ($current_status === 'Maintenance') {
                        $stmt = $pdo->prepare("UPDATE kamar SET status = ?, note = NULL WHERE id_kamar = ?");
                        $stmt->execute([$status, $id_kamar]);
                    } else {
                        $stmt = $pdo->prepare("UPDATE kamar SET status = ? WHERE id_kamar = ?");
                        $stmt->execute([$status, $id_kamar]);
                    }
                }
                
                $success = 'Room status updated successfully';
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'report_damage') {
        $id_pemesanan = isset($_POST['id_pemesanan']) ? (int)$_POST['id_pemesanan'] : 0;
        $jenis_denda = sanitize($_POST['jenis_denda']);
        $jumlah = isset($_POST['jumlah']) ? (float)$_POST['jumlah'] : 0;
        $deskripsi = sanitize($_POST['deskripsi']);
        
        // Validate form data
        if ($id_pemesanan <= 0 || empty($jenis_denda) || $jumlah <= 0) {
            $error = 'All fields are required for damage report';
        } else {
            try {
                // Insert new penalty
                $stmt = $pdo->prepare("
                    INSERT INTO denda (id_pemesanan, jenis_denda, jumlah, status, deskripsi)
                    VALUES (?, ?, ?, 'Belum Dibayar', ?)
                ");
                $stmt->execute([$id_pemesanan, $jenis_denda, $jumlah, $deskripsi]);
                $success = 'Damage reported successfully';
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Get all rooms with their status and current occupancy
try {
    $stmt = $pdo->query("
        SELECT k.*, 
               p.id_pemesanan, p.tanggal_checkin, p.tanggal_checkout, p.status AS booking_status, 
               t.nama_lengkap, t.no_hp
        FROM kamar k
        LEFT JOIN pemesanan p ON k.id_kamar = p.id_kamar AND p.status = 'Check-In'
        LEFT JOIN tamu t ON p.id_tamu = t.id_tamu
        ORDER BY k.nomor_kamar
    ");
    $rooms = $stmt->fetchAll();
    
    // Get current check-ins for damage reporting
    $stmt = $pdo->query("
        SELECT p.id_pemesanan, p.tanggal_checkin, p.tanggal_checkout, 
               t.nama_lengkap, k.nomor_kamar, k.tipe
        FROM pemesanan p
        JOIN tamu t ON p.id_tamu = t.id_tamu
        JOIN kamar k ON p.id_kamar = k.id_kamar
        WHERE p.status = 'Check-In' OR p.status = 'Check-Out'
        ORDER BY p.tanggal_checkin DESC
    ");
    $checkIns = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $rooms = $checkIns = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Housekeeping Dashboard</h1>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Room Status Overview -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Room Status Overview</h6>
        </div>
        <div class="card-body">
            <div class="row">
                <?php 
                $totalRooms = count($rooms);
                $availableRooms = $occupiedRooms = $maintenanceRooms = 0;
                
                foreach ($rooms as $room) {
                    if ($room['status'] === 'Tersedia') $availableRooms++;
                    elseif ($room['status'] === 'Dipesan') $occupiedRooms++;
                    elseif ($room['status'] === 'Maintenance') $maintenanceRooms++;
                }
                ?>
                
                <div class="col-md-4 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Available Rooms</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $availableRooms ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Occupied Rooms</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $occupiedRooms ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-bed fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card border-left-danger shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Maintenance Rooms</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $maintenanceRooms ?></div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-tools fa-2x text-gray-300"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Room List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Room Status Management</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Room</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th>Notes</th>
                            <th>Current Guest</th>
                            <th>Check-In Date</th>
                            <th>Check-Out Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rooms)): ?>
                        <tr>
                            <td colspan="8" class="text-center">No rooms found</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($rooms as $room): ?>
                            <tr>
                                <td><?= $room['nomor_kamar'] ?></td>
                                <td><?= $room['tipe'] ?></td>
                                <td>
                                    <span class="badge bg-<?= $room['status'] === 'Tersedia' ? 'success' : ($room['status'] === 'Dipesan' ? 'warning' : 'danger') ?>">
                                        <?= $room['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($room['status'] === 'Maintenance' && !empty($room['catatan'])): ?>
                                        <button type="button" class="btn btn-sm btn-outline-info" data-bs-toggle="tooltip" data-bs-placement="top" title="<?= htmlspecialchars($room['catatan']) ?>">
                                            <i class="fas fa-info-circle"></i> View Notes
                                        </button>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><?= isset($room['nama_lengkap']) ? $room['nama_lengkap'] : 'N/A' ?></td>
                                <td><?= isset($room['tanggal_checkin']) ? formatDate($room['tanggal_checkin']) : 'N/A' ?></td>
                                <td><?= isset($room['tanggal_checkout']) ? formatDate($room['tanggal_checkout']) : 'N/A' ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#updateStatusModal"
                                            data-id="<?= $room['id_kamar'] ?>"
                                            data-room="<?= $room['nomor_kamar'] ?>"
                                            data-status="<?= $room['status'] ?>"
                                            data-notes="<?= $room['note'] ?? '' ?>">
                                        <i class="fas fa-edit"></i> Update Status
                                    </button>
                                    
                                    <?php if (isset($room['id_pemesanan']) && $room['booking_status'] === 'Check-In'): ?>
                                    <button type="button" class="btn btn-sm btn-danger" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#reportDamageModal"
                                            data-id="<?= $room['id_pemesanan'] ?>"
                                            data-room="<?= $room['nomor_kamar'] ?>"
                                            data-guest="<?= $room['nama_lengkap'] ?>">
                                        <i class="fas fa-exclamation-triangle"></i> Report Issue
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Cleaning Schedule -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Today's Cleaning Schedule</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Room</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $today = date('Y-m-d');
                        $priorityRooms = [];
                        
                        // Rooms with check-outs today are highest priority
                        foreach ($rooms as $room) {
                            if (isset($room['tanggal_checkout']) && date('Y-m-d', strtotime($room['tanggal_checkout'])) === $today) {
                                $priorityRooms[] = [
                                    'room' => $room,
                                    'priority' => 'High',
                                    'notes' => 'Check-out today. Prepare for new guests.'
                                ];
                            } elseif (isset($room['tanggal_checkin']) && date('Y-m-d', strtotime($room['tanggal_checkin'])) === $today) {
                                $priorityRooms[] = [
                                    'room' => $room,
                                    'priority' => 'Medium',
                                    'notes' => 'New guest arriving today.'
                                ];
                            } elseif ($room['status'] === 'Tersedia') {
                                $priorityRooms[] = [
                                    'room' => $room,
                                    'priority' => 'Low',
                                    'notes' => 'Standard cleaning.'
                                ];
                            }
                        }
                        
                        if (empty($priorityRooms)): 
                        ?>
                        <tr>
                            <td colspan="4" class="text-center">No rooms scheduled for cleaning today</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($priorityRooms as $item): ?>
                            <tr>
                                <td><?= $item['room']['nomor_kamar'] ?> (<?= $item['room']['tipe'] ?>)</td>
                                <td>
                                    <span class="badge bg-<?= $item['room']['status'] === 'Tersedia' ? 'success' : ($item['room']['status'] === 'Dipesan' ? 'warning' : 'danger') ?>">
                                        <?= $item['room']['status'] ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-<?= $item['priority'] === 'High' ? 'danger' : ($item['priority'] === 'Medium' ? 'warning' : 'info') ?>">
                                        <?= $item['priority'] ?>
                                    </span>
                                </td>
                                <td>
                                    <?= $item['notes'] ?>
                                    <?php if ($item['room']['status'] === 'Maintenance' && !empty($item['room']['note'])): ?>
                                        <br><small class="text-muted">Maintenance Note: <?= substr($item['room']['note'], 0, 50) ?>...</small>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1" aria-labelledby="updateStatusModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updateStatusModalLabel">Update Room Status</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="id_kamar" id="update_id_kamar">
                    <input type="hidden" name="current_status" id="current_status">
                    
                    <div class="mb-3">
                        <label for="room_number" class="form-label">Room Number</label>
                        <input type="text" class="form-control" id="room_number" readonly>
                    </div>
                    
                    <div class="mb-3">
    <label for="status" class="form-label">Status</label>
    <select class="form-control" id="status" name="status" required>
        <option value="Tersedia">Tersedia</option>
        <option value="Maintenance">Maintenance</option>
        <!-- Hapus opsi Dipesan -->
    </select>
</div>
                    
                    <div class="mb-3" id="maintenance_notes_container" style="display: none;">
                        <label for="maintenance_notes" class="form-label">Maintenance Notes</label>
                        <textarea class="form-control" id="maintenance_notes" name="maintenance_notes" rows="3"><?= isset($room['note']) ? $room['note'] : '' ?></textarea>
                        <small class="form-text text-muted">Please describe the maintenance issue in detail.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Report Damage Modal -->
<div class="modal fade" id="reportDamageModal" tabindex="-1" aria-labelledby="reportDamageModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="reportDamageModalLabel">Report Damage or Issue</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="report_damage">
                    <input type="hidden" name="id_pemesanan" id="damage_id_pemesanan">
                    
                    <div class="mb-3">
                        <label for="damage_room" class="form-label">Room</label>
                        <input type="text" class="form-control" id="damage_room" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="damage_guest" class="form-label">Guest</label>
                        <input type="text" class="form-control" id="damage_guest" readonly>
                    </div>
                    
                    <div class="mb-3">
                        <label for="jenis_denda" class="form-label">Type of Damage/Issue</label>
                        <input type="text" class="form-control" id="jenis_denda" name="jenis_denda" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Fine Amount</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Description</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
                        <small class="form-text text-muted">Please provide detailed description of the damage or issue.</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Handle update status button clicks
    const updateButtons = document.querySelectorAll('[data-bs-target="#updateStatusModal"]');
    updateButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get room data from button attributes
            const roomId = this.dataset.id;
            const roomNumber = this.dataset.room;
            const roomStatus = this.dataset.status;
            const roomNotes = this.dataset.notes || '';
            
            // Fill form fields with room data
            document.getElementById('update_id_kamar').value = roomId;
            document.getElementById('room_number').value = roomNumber;
            document.getElementById('status').value = roomStatus;
            document.getElementById('current_status').value = roomStatus;
            document.getElementById('maintenance_notes').value = roomNotes;
            
            // Show/hide maintenance notes based on selected status
            toggleMaintenanceNotes();
        });
    });
    
    // Handle status change
    const statusSelect = document.getElementById('status');
    if (statusSelect) {
        statusSelect.addEventListener('change', toggleMaintenanceNotes);
    }
    
    function toggleMaintenanceNotes() {
        const statusValue = document.getElementById('status').value;
        const maintenanceNotesContainer = document.getElementById('maintenance_notes_container');
        
        if (statusValue === 'Maintenance') {
            maintenanceNotesContainer.style.display = 'block';
            document.getElementById('maintenance_notes').setAttribute('required', 'required');
        } else {
            maintenanceNotesContainer.style.display = 'none';
            document.getElementById('maintenance_notes').removeAttribute('required');
        }
    }
    
    // Handle report damage button clicks
    const reportButtons = document.querySelectorAll('[data-bs-target="#reportDamageModal"]');
    reportButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get data from button attributes
            const bookingId = this.dataset.id;
            const roomNumber = this.dataset.room;
            const guestName = this.dataset.guest;
            
            // Fill form fields with data
            document.getElementById('damage_id_pemesanan').value = bookingId;
            document.getElementById('damage_room').value = roomNumber;
            document.getElementById('damage_guest').value = guestName;
        });
    });
});
</script>