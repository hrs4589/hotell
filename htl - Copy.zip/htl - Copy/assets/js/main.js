/**
* Template Name: NiceAdmin (Modified for Hotel Management System)
* Updated: May 03 2025 with Bootstrap v5.2.3
* Main JS Script for Hotel Management System
*/
(function() {
  "use strict";

  /**
   * Fungsi pemilihan elemen yang lebih mudah
   */
  const select = (el, all = false) => {
    el = el.trim()
    if (all) {
      return [...document.querySelectorAll(el)]
    } else {
      return document.querySelector(el)
    }
  }

  /**
   * Fungsi event listener yang lebih mudah
   */
  const on = (type, el, listener, all = false) => {
    if (all) {
      select(el, all).forEach(e => e.addEventListener(type, listener))
    } else {
      select(el).addEventListener(type, listener)
    }
  }

  /**
   * Fungsi listener scroll yang lebih mudah
   */
  const onscroll = (el, listener) => {
    el.addEventListener('scroll', listener)
  }

  /**
   * Toggle Sidebar
   */
  if (select('.toggle-sidebar-btn')) {
    on('click', '.toggle-sidebar-btn', function(e) {
      select('body').classList.toggle('toggle-sidebar')
    })
  }

  /**
   * Toggle Sidebar untuk Layar Kecil (Mobile)
   */
  document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk menangani responsive sidebar di perangkat mobile
    const toggleMobileSidebar = function() {
      if (window.innerWidth < 1200) {
        select('body').classList.add('toggle-sidebar');
      }
    };

    // Jalankan saat halaman dimuat
    toggleMobileSidebar();

    // Tambahkan event listener untuk resizing
    window.addEventListener('resize', toggleMobileSidebar);

    // Tambahkan onclick event untuk tombol toggle sidebar
    const sidebarToggler = select('.toggle-sidebar-btn');
    if (sidebarToggler) {
      sidebarToggler.addEventListener('click', function() {
        select('body').classList.toggle('toggle-sidebar');
      });
    }

    // Tutup sidebar saat mengklik di luar sidebar pada layar kecil
    document.addEventListener('click', function(e) {
      const sidebar = select('.sidebar');
      const sidebarToggler = select('.toggle-sidebar-btn');
      
      if (window.innerWidth < 1200 && 
          sidebar && 
          !sidebar.contains(e.target) && 
          sidebarToggler && 
          !sidebarToggler.contains(e.target)) {
        select('body').classList.add('toggle-sidebar');
      }
    });
  });

  /**
   * Toggle search bar
   */
  if (select('.search-bar-toggle')) {
    on('click', '.search-bar-toggle', function(e) {
      select('.search-bar').classList.toggle('search-bar-show')
    })
  }

  /**
   * Status aktif link navbar saat scroll
   */
  let navbarlinks = select('#navbar .scrollto', true)
  const navbarlinksActive = () => {
    let position = window.scrollY + 200
    navbarlinks.forEach(navbarlink => {
      if (!navbarlink.hash) return
      let section = select(navbarlink.hash)
      if (!section) return
      if (position >= section.offsetTop && position <= (section.offsetTop + section.offsetHeight)) {
        navbarlink.classList.add('active')
      } else {
        navbarlink.classList.remove('active')
      }
    })
  }
  window.addEventListener('load', navbarlinksActive)
  onscroll(document, navbarlinksActive)

  /**
   * Toggle class .header-scrolled ke #header saat halaman di-scroll
   */
  let selectHeader = select('#header')
  if (selectHeader) {
    const headerScrolled = () => {
      if (window.scrollY > 100) {
        selectHeader.classList.add('header-scrolled')
      } else {
        selectHeader.classList.remove('header-scrolled')
      }
    }
    window.addEventListener('load', headerScrolled)
    onscroll(document, headerScrolled)
  }

  /**
   * Tombol kembali ke atas
   */
  let backtotop = select('.back-to-top')
  if (backtotop) {
    const toggleBacktotop = () => {
      if (window.scrollY > 100) {
        backtotop.classList.add('active')
      } else {
        backtotop.classList.remove('active')
      }
    }
    window.addEventListener('load', toggleBacktotop)
    onscroll(document, toggleBacktotop)
  }

  /**
   * Inisialisasi tooltips
   */
  document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl)
    });
    
    // Inisialisasi Popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
      return new bootstrap.Popover(popoverTriggerEl, {
        trigger: 'focus'
      })
    });
  });

  /**
   * Inisialisasi quill editors jika ada
   */
  if (select('.quill-editor-default')) {
    if (typeof Quill !== 'undefined') {
      new Quill('.quill-editor-default', {
        theme: 'snow'
      });
    }
  }

  if (select('.quill-editor-bubble')) {
    if (typeof Quill !== 'undefined') {
      new Quill('.quill-editor-bubble', {
        theme: 'bubble'
      });
    }
  }

  if (select('.quill-editor-full')) {
    if (typeof Quill !== 'undefined') {
      new Quill(".quill-editor-full", {
        modules: {
          toolbar: [
            [{
              font: []
            }, {
              size: []
            }],
            ["bold", "italic", "underline", "strike"],
            [{
                color: []
              },
              {
                background: []
              }
            ],
            [{
                script: "super"
              },
              {
                script: "sub"
              }
            ],
            [{
                list: "ordered"
              },
              {
                list: "bullet"
              },
              {
                indent: "-1"
              },
              {
                indent: "+1"
              }
            ],
            ["direction", {
              align: []
            }],
            ["link", "image", "video"],
            ["clean"]
          ]
        },
        theme: "snow"
      });
    }
  }

  /**
   * Inisialisasi TinyMCE Editor jika ada
   */
  if (typeof tinymce !== 'undefined') {
    const useDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const isSmallScreen = window.matchMedia('(max-width: 1023.5px)').matches;

    tinymce.init({
      selector: 'textarea.tinymce-editor',
      plugins: 'preview importcss searchreplace autolink autosave save directionality code visualblocks visualchars fullscreen image link media template codesample table charmap pagebreak nonbreaking anchor insertdatetime advlist lists wordcount help charmap quickbars emoticons',
      editimage_cors_hosts: ['picsum.photos'],
      menubar: 'file edit view insert format tools table help',
      toolbar: 'undo redo | bold italic underline strikethrough | fontfamily fontsize blocks | alignleft aligncenter alignright alignjustify | outdent indent |  numlist bullist | forecolor backcolor removeformat | pagebreak | charmap emoticons | fullscreen  preview save print | insertfile image media template link anchor codesample | ltr rtl',
      toolbar_sticky: true,
      toolbar_sticky_offset: isSmallScreen ? 102 : 108,
      autosave_ask_before_unload: true,
      autosave_interval: '30s',
      autosave_prefix: '{path}{query}-{id}-',
      autosave_restore_when_empty: false,
      autosave_retention: '2m',
      image_advtab: true,
      link_list: [{
          title: 'Halaman 1',
          value: 'https://www.example.com'
        },
        {
          title: 'Halaman 2',
          value: 'https://www.example.org'
        }
      ],
      image_list: [{
          title: 'Gambar 1',
          value: 'https://www.example.com/image1.jpg'
        },
        {
          title: 'Gambar 2',
          value: 'https://www.example.com/image2.jpg'
        }
      ],
      image_class_list: [{
          title: 'Tidak Ada',
          value: ''
        },
        {
          title: 'Beberapa kelas',
          value: 'class-name'
        }
      ],
      importcss_append: true,
      file_picker_callback: (callback, value, meta) => {
        /* Dialog untuk link */
        if (meta.filetype === 'file') {
          callback('https://www.example.com/document.pdf', {
            text: 'Dokumen Contoh'
          });
        }

        /* Dialog untuk gambar */
        if (meta.filetype === 'image') {
          callback('https://www.example.com/image.jpg', {
            alt: 'Teks Alt Saya'
          });
        }

        /* Dialog untuk media */
        if (meta.filetype === 'media') {
          callback('video.mp4', {
            source2: 'alt.ogg',
            poster: 'https://www.example.com/poster.jpg'
          });
        }
      },
      templates: [{
          title: 'Tabel Baru',
          description: 'membuat tabel baru',
          content: '<div class="mceTmpl"><table width="98%%"  border="0" cellspacing="0" cellpadding="0"><tr><th scope="col"> </th><th scope="col"> </th></tr><tr><td> </td><td> </td></tr></table></div>'
        },
        {
          title: 'Mulai cerita',
          description: 'Template untuk mulai menulis',
          content: 'Pada suatu hari...'
        },
        {
          title: 'Daftar baru dengan tanggal',
          description: 'Daftar Baru dengan tanggal',
          content: '<div class="mceTmpl"><span class="cdate">cdate</span><br><span class="mdate">mdate</span><h2>Daftar Saya</h2><ul><li></li><li></li></ul></div>'
        }
      ],
      template_cdate_format: '[Tanggal Dibuat: %d/%m/%Y : %H:%M:%S]',
      template_mdate_format: '[Tanggal Diubah: %d/%m/%Y : %H:%M:%S]',
      height: 600,
      image_caption: true,
      quickbars_selection_toolbar: 'bold italic | quicklink h2 h3 blockquote quickimage quicktable',
      noneditable_class: 'mceNonEditable',
      toolbar_mode: 'sliding',
      contextmenu: 'link image table',
      skin: useDarkMode ? 'oxide-dark' : 'oxide',
      content_css: useDarkMode ? 'dark' : 'default',
      content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px }'
    });
  }

  /**
   * Inisialisasi validasi Bootstrap
   */
  var needsValidation = document.querySelectorAll('.needs-validation')

  Array.prototype.slice.call(needsValidation)
    .forEach(function(form) {
      form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add('was-validated')
      }, false)
    })

  /**
   * Inisialisasi DataTables jika ada
   */
  document.addEventListener('DOMContentLoaded', function() {
    const datatables = select('.datatable', true)
    datatables.forEach(datatable => {
      if (typeof simpleDatatables !== 'undefined') {
        new simpleDatatables.DataTable(datatable, {
          searchable: true,
          fixedHeight: true,
          perPage: 10,
          labels: {
            placeholder: "Cari...",
            perPage: "{select} data per halaman",
            noRows: "Tidak ada data yang ditemukan",
            info: "Menampilkan {start} sampai {end} dari {rows} data"
          }
        });
      }
    });
  });

  /**
   * Status Kamar (untuk menandai kamar yang tidak tersedia)
   */
  document.addEventListener('DOMContentLoaded', function() {
    // Periksa kamar yang sudah dipesan dan nonaktifkan tombol pemesanan
    const bookButtons = document.querySelectorAll('.book-room-btn');
    bookButtons.forEach(btn => {
      const roomId = btn.getAttribute('data-room-id');
      const isBooked = btn.getAttribute('data-is-booked');
      
      if (isBooked === 'true') {
        btn.classList.add('disabled');
        btn.textContent = 'Tidak Tersedia';
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-secondary');
        
        // Tambahkan warna latar belakang abu-abu ke kamar yang tidak tersedia
        const roomCard = btn.closest('.room-card');
        if (roomCard) {
          roomCard.classList.add('room-booked');
          roomCard.style.opacity = '0.7';
        }
      }
    });
  });

  /**
   * Handler Modal Detail
   */
  document.addEventListener('DOMContentLoaded', function() {
    // Tangani modal info detail
    const detailButtons = document.querySelectorAll('.btn-detail');
    detailButtons.forEach(btn => {
      btn.addEventListener('click', function() {
        const targetModal = this.getAttribute('data-bs-target');
        const modal = document.querySelector(targetModal);
        
        if (modal) {
          // Muat data tambahan jika diperlukan melalui AJAX
          const itemId = this.getAttribute('data-id');
          const itemType = this.getAttribute('data-type');
          
          // Implementasikan pemuatan AJAX jika diperlukan
        }
      });
    });
  });

  /**
   * Kode warna status transaksi
   */
  document.addEventListener('DOMContentLoaded', function() {
    const statusElements = document.querySelectorAll('.transaction-status');
    statusElements.forEach(element => {
      const status = element.textContent.trim().toLowerCase();
      
      if (status === 'menunggu' || status === 'pending') {
        element.classList.add('badge', 'bg-warning', 'text-dark');
      } else if (status === 'dikonfirmasi' || status === 'confirmed') {
        element.classList.add('badge', 'bg-info');
      } else if (status === 'check-in') {
        element.classList.add('badge', 'bg-primary');
      } else if (status === 'check-out') {
        element.classList.add('badge', 'bg-success');
      } else if (status === 'dibatalkan' || status === 'cancelled') {
        element.classList.add('badge', 'bg-danger');
      }
    });
  });

  /**
   * Galeri gambar kamar
   */
  document.addEventListener('DOMContentLoaded', function() {
    // Tampilkan gambar kamar dalam galeri saat diklik
    const roomImages = document.querySelectorAll('.room-image');
    
    roomImages.forEach(img => {
      img.addEventListener('click', function() {
        const roomModal = this.closest('.room-card').querySelector('.modal-room-gallery');
        if (roomModal) {
          const bsModal = new bootstrap.Modal(roomModal);
          bsModal.show();
        }
      });
    });
  });

  /**
   * Resize otomatis untuk chart echart
   */
  const mainContainer = select('#main');
  if (mainContainer) {
    setTimeout(() => {
      new ResizeObserver(function() {
        select('.echart', true).forEach(getEchart => {
          if (typeof echarts !== 'undefined' && echarts.getInstanceByDom) {
            const chart = echarts.getInstanceByDom(getEchart);
            if (chart) {
              chart.resize();
            }
          }
        });
      }).observe(mainContainer);
    }, 200);
  }

})();