<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Redirect if already logged in
if (isGuestLoggedIn() || isStaffLoggedIn()) {
    redirect('index.php');
}

$error = '';
$success = '';

// Process registration form (existing logic remains the same)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ... [existing PHP code remains exactly the same] ...
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Daftar - Sistem Manajemen Hotel</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  
  <style>
    .slim-card {
      max-width: 600px;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    }
    .slim-card .card-body {
      padding: 1.5rem;
    }
    .compact-form .form-control {
      padding: 0.35rem 0.7rem;
      font-size: 0.85rem;
      height: calc(1.6em + 0.7rem + 2px);
    }
    .compact-form label {
      font-size: 0.82rem;
      margin-bottom: 0.2rem;
      font-weight: 500;
    }
    .compact-form .btn {
      padding: 0.35rem 0.7rem;
      font-size: 0.85rem;
    }
    .form-title {
      font-size: 1.1rem;
      margin-bottom: 0.3rem;
    }
    .form-subtitle {
      font-size: 0.78rem;
      margin-bottom: 1.2rem;
    }
    .form-divider {
      border-right: 1px solid #e9ecef;
    }
    @media (max-width: 768px) {
      .form-divider {
        border-right: none;
        padding-bottom: 0.5rem;
        margin-bottom: 0.5rem;
      }
      .slim-card {
        margin-top: 0.5rem;
      }
    }
  </style>
</head>

<body>

  <main>
    <div class="container py-3">
      <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
          <div class="d-flex justify-content-center mb-3">
            <a href="index.php" class="logo d-flex align-items-center text-decoration-none">
              <svg class="me-2" width="26px" height="26px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                <path d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5zM2 11h1v1H2zm2 0h1v1H4zm-1 2v1H2v-1zm1 0h1v1H4zm9-10v1h-1V3zM8 5h1v1H8zm1 2v1H8V7zM8 9h1v1H8zm2 0h1v1h-1zm-1 2v1H8v-1zm1 0h1v1h-1zm3-2v1h-1V9zm-1 2h1v1h-1zm-2-4h1v1h-1zm3 0v1h-1V7zm-2-2v1h-1V5zm1 0h1v1h-1z"/>
              </svg>
              <span class="fw-semibold">Magelang Hotel</span>
            </a>
          </div>

          <div class="card slim-card mb-3">
            <div class="card-body">
              <div class="text-center mb-3">
                <h5 class="form-title text-dark mb-1">Buat Akun Tamu</h5>
                <p class="form-subtitle text-muted">Isi data diri Anda untuk mendaftar</p>
              </div>

              <?php if ($error): ?>
              <div class="alert alert-danger py-2 mb-3">
                <?= $error ?>
              </div>
              <?php endif; ?>
              
              <?php if ($success): ?>
              <div class="alert alert-success py-2 mb-3">
                <?= $success ?>
                <p class="mt-2 mb-0 small"><a href="guest_login.php" class="alert-link">Klik di sini untuk login</a></p>
              </div>
              <?php else: ?>

              <form class="compact-form" method="POST">
                <div class="row g-2">
                  <div class="col-md-6 pe-2 form-divider">
                    <div class="mb-2">
                      <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                      <input type="text" name="nama_lengkap" class="form-control" id="nama_lengkap" required>
                    </div>
                    
                    <div class="mb-2">
                      <label for="no_ktp" class="form-label">Nomor KTP</label>
                      <input type="text" name="no_ktp" class="form-control" id="no_ktp" required>
                    </div>
                    
                    <div class="mb-2">
                      <label for="no_hp" class="form-label">Nomor HP</label>
                      <input type="text" name="no_hp" class="form-control" id="no_hp" required>
                    </div>
                    
                    <div class="mb-2">
                      <label for="email" class="form-label">Email</label>
                      <input type="email" name="email" class="form-control" id="email">
                    </div>
                  </div>
                  
                  <div class="col-md-6 ps-2">
                    <div class="mb-2">
                      <label for="alamat" class="form-label">Alamat</label>
                      <textarea class="form-control" name="alamat" id="alamat" rows="2"></textarea>
                    </div>
                    
                    <div class="mb-2">
                      <label for="username" class="form-label">Username</label>
                      <div class="input-group">
                        <span class="input-group-text">@</span>
                        <input type="text" name="username" class="form-control" id="username" required>
                      </div>
                    </div>
                    
                    <div class="mb-2">
                      <label for="password" class="form-label">Password</label>
                      <input type="password" name="password" class="form-control" id="password" required>
                    </div>
                    
                    <div class="mb-3">
                      <label for="confirm_password" class="form-label">Konfirmasi Password</label>
                      <input type="password" name="confirm_password" class="form-control" id="confirm_password" required>
                    </div>
                  </div>
                </div>
                
                <div class="d-grid mt-1">
                  <button class="btn btn-primary" type="submit">Daftar Sekarang</button>
                </div>
              </form>

              <div class="text-center mt-3 small">
                Sudah punya akun? <a href="login.php" class="text-decoration-none">Login disini</a>
              </div>

              <?php endif; ?>
            </div>
          </div>

          <div class="text-center small text-muted mt-3">
             &copy; Copyright <strong><span>Sistem Manajemen Hotel</span></strong> <?= date('Y') ?>. 
        
          </div>
        </div>
      </div>
    </div>
  </main>

  <!-- Vendor JS Files -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/main.js"></script>

</body>
</html>