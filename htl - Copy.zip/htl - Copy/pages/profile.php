<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user is logged in
if (!isStaffLoggedIn()) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You must be logged in to access this page.</div></div>';
    exit;
}

// Process form submission
$success = $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if ($action === 'update_profile') {
        $nama_lengkap = sanitize($_POST['nama_lengkap']);
        
        if (empty($nama_lengkap)) {
            $error = 'Full name is required';
        } else {
            try {
                // Update staff data
                $stmt = $pdo->prepare("UPDATE staff SET nama_lengkap = ? WHERE id_staff = ?");
                $stmt->execute([$nama_lengkap, $_SESSION['staff_id']]);
                
                // Update session variable
                $_SESSION['fullname'] = $nama_lengkap;
                
                $success = 'Profile updated successfully';
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error = 'All password fields are required';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New password and confirmation do not match';
        } else {
            try {
                // Get current password from database
                $stmt = $pdo->prepare("SELECT password FROM staff WHERE id_staff = ?");
                $stmt->execute([$_SESSION['staff_id']]);
                $staff = $stmt->fetch();
                
                if (!$staff) {
                    $error = 'User not found';
                } else {
                    // Verify current password
                    if (password_verify($current_password, $staff['password']) || $current_password === $staff['password']) {
                        // Hash new password
                        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                        
                        // Update password
                        $stmt = $pdo->prepare("UPDATE staff SET password = ? WHERE id_staff = ?");
                        $stmt->execute([$hashed_password, $_SESSION['staff_id']]);
                        
                        $success = 'Password changed successfully';
                    } else {
                        $error = 'Current password is incorrect';
                    }
                }
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Get staff data
try {
    $stmt = $pdo->prepare("SELECT * FROM staff WHERE id_staff = ?");
    $stmt->execute([$_SESSION['staff_id']]);
    $staff = $stmt->fetch();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $staff = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">My Profile</h1>
    
    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-6">
            <!-- Profile Information -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Profile Information</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" value="<?= $staff['username'] ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="nama_lengkap" class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" value="<?= $staff['nama_lengkap'] ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role" class="form-label">Role</label>
                            <input type="text" class="form-control" id="role" value="<?= $staff['role'] ?>" readonly>
                        </div>
                        
                        <div class="mb-3">
                            <label for="last_login" class="form-label">Last Login</label>
                            <input type="text" class="form-control" id="last_login" value="<?= $staff['last_login'] ? date('d/m/Y H:i', strtotime($staff['last_login'])) : 'Never' ?>" readonly>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Update Profile</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-6">
            <!-- Change Password -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Change Password</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
