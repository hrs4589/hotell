<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Periksa apakah pengguna sudah login
if (!isStaffLoggedIn() && !isGuestLoggedIn()) {
    redirect('login.php');
}

// Ambil halaman saat ini dari parameter URL
$page = getCurrentPage();

// Periksa apakah pengguna memiliki akses ke halaman yang diminta
if (!hasPageAccess($page)) {
    // Arahkan ke dashboard yang sesuai berdasarkan jenis pengguna
    if (isStaffLoggedIn()) {
        redirect('index.php?page=dashboard');
    } else {
        redirect('index.php?page=guest/dashboard');
    }
}

// Proses permintaan AJAX jika ada
if (isset($_GET['ajax']) && $_GET['ajax'] === 'true') {
    // Tangani permintaan AJAX di sini
    header('Content-Type: application/json');
    // Contoh: mengembalikan ketersediaan kamar
    if (isset($_GET['action']) && $_GET['action'] === 'check_room') {
        $roomId = isset($_GET['room_id']) ? (int)$_GET['room_id'] : 0;
        $checkin = isset($_GET['checkin']) ? $_GET['checkin'] : '';
        $checkout = isset($_GET['checkout']) ? $_GET['checkout'] : '';
        
        // Periksa apakah kamar tersedia untuk tanggal yang diberikan
        try {
            global $pdo;
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM pemesanan 
                WHERE id_kamar = ? 
                AND (
                    (tanggal_checkin BETWEEN ? AND ?) 
                    OR (tanggal_checkout BETWEEN ? AND ?)
                    OR (? BETWEEN tanggal_checkin AND tanggal_checkout)
                )
                AND status IN ('Menunggu', 'Dikonfirmasi', 'Check-In')
            ");
            $stmt->execute([$roomId, $checkin, $checkout, $checkin, $checkout, $checkin]);
            $isBooked = $stmt->fetchColumn() > 0;
            
            echo json_encode(['available' => !$isBooked]);
        } catch (PDOException $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        exit;
    }
}

// Dapatkan halaman saat ini untuk menyorot menu aktif
$currentPage = getCurrentPage();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Sistem Manajemen Hotel">
    <meta name="author" content="Developer">
    
    <title>Sistem Manajemen Hotel</title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
    
    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    
    <!-- Vendor CSS Files -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css" rel="stylesheet">
    
    <!-- Template Main CSS File -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Custom Styles for Room Images, Dashboard, and Mobile Sidebar -->
    <style>
    /* Dashboard Enhancements */
    .welcome-card {
        border-radius: 1rem;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    .welcome-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 0.5rem 2rem rgba(0, 0, 0, 0.15) !important;
    }
    .welcome-decoration {
        position: absolute;
        top: 15px;
        right: 15px;
        font-size: 2.5rem;
        opacity: 0.1;
    }
    .icon-circle {
        width: 48px;
        height: 48px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
    }
    .pulse-animation {
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0% {
            box-shadow: 0 0 0 0 rgba(65, 84, 241, 0.7);
        }
        70% {
            box-shadow: 0 0 0 10px rgba(65, 84, 241, 0);
        }
        100% {
            box-shadow: 0 0 0 0 rgba(65, 84, 241, 0);
        }
    }
    .quick-links .btn {
        transition: all 0.3s;
    }
    .quick-links .btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .bg-gradient-primary-to-secondary {
        background: linear-gradient(135deg, #4154f1 0%, #2536b3 100%);
    }
    .bg-gradient-info-to-primary {
        background: linear-gradient(135deg, #36b9cc 0%, #1a96ab 100%);
    }
    .bg-primary-soft {
        background-color: rgba(65, 84, 241, 0.15);
    }
    .bg-success-soft {
        background-color: rgba(40, 167, 69, 0.15);
    }
    .bg-info-soft {
        background-color: rgba(54, 185, 204, 0.15);
    }
    .bg-warning-soft {
        background-color: rgba(246, 194, 62, 0.15);
    }
    .stat-card {
        transition: all 0.3s ease;
        border-radius: 0.8rem;
    }
    .stat-card:hover {
        transform: translateY(-7px);
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.12) !important;
    }
    .progress-sm {
        height: 5px;
        border-radius: 5px;
    }
    .avatar {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
    }
    .avatar-sm {
        width: 32px;
        height: 32px;
        font-size: 0.875rem;
    }
    .icon-square {
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 5px;
    }
    .booking-table th {
        font-weight: 600;
        border-top: none;
    }
    .booking-table td {
        padding: 1rem 0.75rem;
        vertical-align: middle;
    }
    .empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }
    .font-weight-medium {
        font-weight: 500;
    }
    .status-indicator {
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    
    /* Gaya untuk kamar yang sudah dipesan */
    .room-booked {
        position: relative;
    }
    .room-booked::after {
        content: "Tidak Tersedia";
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0,0,0,0.6);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        font-weight: bold;
        backdrop-filter: blur(3px);
        -webkit-backdrop-filter: blur(3px);
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    .room-booked:hover::after {
        opacity: 1;
    }
    
    /* Gaya untuk galeri gambar kamar - enhanced */
    .room-image {
        cursor: pointer;
        transition: all 0.5s ease;
        height: 220px;
        width: 100%;
        object-fit: cover;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        filter: brightness(0.95);
    }
    .room-image:hover {
        transform: scale(1.03);
        filter: brightness(1.05);
        box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
    }
    
    /* Card room styling enhancement */
    .room-card {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
        margin-bottom: 30px;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: none;
        background-color: #fff;
    }
    .room-card:hover {
        transform: translateY(-10px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.12);
    }
    .room-card .card-header {
        border: none;
        padding: 0;
        position: relative;
        overflow: hidden;
    }
    .room-card .card-body {
        padding: 20px;
    }
    .room-card .room-title {
        font-size: 1.3rem;
        font-weight: 700;
        color: #012970;
        margin-bottom: 10px;
    }
    .room-card .room-price {
        font-size: 1.5rem;
        font-weight: 700;
        color: #4154f1;
        margin: 15px 0;
    }
    .room-card .room-price small {
        font-size: 0.9rem;
        color: #6c757d;
        font-weight: 400;
    }
    .room-card .room-features {
        margin: 15px 0;
        padding: 0;
        list-style: none;
    }
    .room-card .room-features li {
        margin-bottom: 8px;
        position: relative;
        padding-left: 25px;
    }
    .room-card .room-features li:before {
        content: "✓";
        color: #4154f1;
        position: absolute;
        left: 0;
        top: 0;
        font-weight: bold;
    }
    .room-card .btn-book {
        width: 100%;
        border-radius: 50px;
        padding: 10px;
        font-weight: 600;
        margin-top: 15px;
        transition: all 0.3s ease;
    }
    
    /* Status transaksi */
    .transaction-status {
        font-weight: bold;
        padding: 5px 10px;
        border-radius: 4px;
    }
    
    /* Warna untuk status pemesanan */
    .badge.bg-menunggu {
        background-color: #f6c23e;
        color: #000;
    }
    .badge.bg-dikonfirmasi {
        background-color: #4e73df;
        color: #fff;
    }
    .badge.bg-checkin {
        background-color: #36b9cc;
        color: #fff;
    }
    .badge.bg-checkout {
        background-color: #1cc88a;
        color: #fff;
    }
    .badge.bg-dibatalkan {
        background-color: #e74a3b;
        color: #fff;
    }
    
    /* Status untuk tabel pemesanan - enhanced */
    
    /* Styling untuk kamar yang tidak tersedia */
    .room-unavailable {
        opacity: 0.8;
        position: relative;
    }
    .room-unavailable img {
        filter: grayscale(70%);
    }
    .room-status-overlay {
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 10;
    }
    .room-status-overlay .badge {
        font-size: 0.8rem;
        padding: 0.35em 0.65em;
        box-shadow: 0 2px 5px rgba(0,0,0,0.2);
    }
    span.menunggu {
        background-color: #f6c23e;
        color: #000;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 0.85rem;
        display: inline-block;
        box-shadow: 0 2px 5px rgba(246, 194, 62, 0.3);
    }
    span.dikonfirmasi {
        background-color: #4e73df;
        color: #fff;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 0.85rem;
        display: inline-block;
        box-shadow: 0 2px 5px rgba(78, 115, 223, 0.3);
    }
    span.checkin {
        background-color: #36b9cc;
        color: #fff;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 0.85rem;
        display: inline-block;
        box-shadow: 0 2px 5px rgba(54, 185, 204, 0.3);
    }
    span.checkout {
        background-color: #1cc88a;
        color: #fff;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 0.85rem;
        display: inline-block;
        box-shadow: 0 2px 5px rgba(28, 200, 138, 0.3);
    }
    span.dibatalkan {
        background-color: #e74a3b;
        color: #fff;
        font-weight: 600;
        padding: 5px 12px;
        border-radius: 30px;
        font-size: 0.85rem;
        display: inline-block;
        box-shadow: 0 2px 5px rgba(231, 74, 59, 0.3);
    }
    
    /* Table styling enhancement */
    .table-modern {
        border-collapse: separate;
        border-spacing: 0;
        width: 100%;
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 5px 12px rgba(0,0,0,0.08);
    }
    .table-modern thead th {
        padding: 15px;
        background: linear-gradient(135deg, #4154f1, #2536b3);
        color: white;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.85rem;
        letter-spacing: 0.5px;
        border: none;
    }
    .table-modern tbody tr {
        transition: all 0.2s ease;
    }
    .table-modern tbody tr:hover {
        background-color: rgba(65, 84, 241, 0.05);
        transform: scale(1.005);
        box-shadow: 0 3px 8px rgba(0,0,0,0.05);
    }
    .table-modern td {
        padding: 12px 15px;
        vertical-align: middle;
        border-bottom: 1px solid #e9ecef;
    }
    
    /* Sidebar Responsive Behaviour */
    @media (max-width: 1199px) {
        body:not(.toggle-sidebar) .sidebar {
            left: -300px;
        }
        .sidebar {
            transition: all 0.3s;
            z-index: 999;
        }
        body.toggle-sidebar .sidebar {
            left: 0;
        }
        .toggle-sidebar-btn {
            cursor: pointer;
        }
    }
    
    /* Card styling - enhanced */
    .card-hotel {
        border-radius: 15px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.08);
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        margin-bottom: 25px;
        border: none;
        overflow: hidden;
    }
    .card-hotel:hover {
        transform: translateY(-7px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.12);
    }
    .card-header-hotel {
        background: linear-gradient(135deg, #4154f1, #2536b3);
        color: white;
        border-radius: 15px 15px 0 0;
        padding: 18px 20px;
        font-weight: 600;
        letter-spacing: 0.5px;
    }
    /* Button improvements */
    .btn-modern {
        border-radius: 50px;
        padding: 8px 25px;
        font-weight: 500;
        letter-spacing: 0.3px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    .btn-modern::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: -2;
    }
    .btn-modern::before {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 0%;
        height: 100%;
        background-color: rgba(255, 255, 255, 0.2);
        transition: all .3s;
        z-index: -1;
    }
    .btn-modern:hover::before {
        width: 100%;
    }
    </style>
</head>

<body>
<?php if (isStaffLoggedIn()): ?>
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

       <div class="d-flex align-items-center justify-content-between">
    <a href="index.php" class="logo d-flex align-items-center">
        <svg class="me-2" width="35px" height="35px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
            <path d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5zM2 11h1v1H2zm2 0h1v1H4zm-1 2v1H2v-1zm1 0h1v1H4zm9-10v1h-1V3zM8 5h1v1H8zm1 2v1H8V7zM8 9h1v1H8zm2 0h1v1h-1zm-1 2v1H8v-1zm1 0h1v1h-1zm3-2v1h-1V9zm-1 2h1v1h-1zm-2-4h1v1h-1zm3 0v1h-1V7zm-2-2v1h-1V5zm1 0h1v1h-1z"/>
        </svg>
        <span class="d-none d-lg-block">Sistem Hotel</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
</div><!-- End Logo -->


        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <li class="nav-item dropdown pe-3">

                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                       <svg width="30px" height="30px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
</svg><span class="d-none d-md-block dropdown-toggle ps-2"><?= getUserFullName() ?></span>
                    </a><!-- End Profile Image Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?= getUserFullName() ?></h6>
                            <span><?= getUserRole() ?></span>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="index.php?page=profile">
                                <i class="bi bi-person"></i>
                                <span>Profil Saya</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Keluar</span>
                            </a>
                        </li>

                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'dashboard' ? '' : 'collapsed' ?>" href="index.php?page=dashboard">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <?php if (hasRole(['Resepsionis'])): ?>
            <li class="nav-item">
                <a class="nav-link <?= in_array($currentPage, ['kamar', 'tamu', 'pemesanan', 'denda']) ? '' : 'collapsed' ?>" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-menu-button-wide"></i><span>Manajemen Hotel</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="components-nav" class="nav-content collapse <?= in_array($currentPage, ['kamar', 'tamu', 'pemesanan', 'denda']) ? 'show' : '' ?>" data-bs-parent="#sidebar-nav">
                  <li>
                        <a href="index.php?page=kamar" class="<?= $currentPage === 'kamar' ? 'active' : '' ?>">
                            <i class="bi bi-circle"></i><span>Kamar</span>
                        </a>
                    </li>
                    <li>
                        <a href="index.php?page=tamu" class="<?= $currentPage === 'tamu' ? 'active' : '' ?>">
                            <i class="bi bi-circle"></i><span>Tamu</span>
                        </a>
                    </li>
                    <li>
                        <a href="index.php?page=pemesanan" class="<?= $currentPage === 'pemesanan' ? 'active' : '' ?>">
                            <i class="bi bi-circle"></i><span>Pemesanan</span>
                        </a>
                    </li>
                    <li>
                        <a href="index.php?page=denda" class="<?= $currentPage === 'denda' ? 'active' : '' ?>">
                            <i class="bi bi-circle"></i><span>Denda</span>
                        </a>
                    </li>
                </ul>
            </li><!-- End Management Nav -->
            <?php endif; ?>
            <?php if (hasRole([ 'Manajer'])): ?>
            <li class="nav-item">
                <a class="nav-link <?= in_array($currentPage, ['kamar', 'staff', 'reports', 'denda']) ? '' : 'collapsed' ?>" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                    <i class="bi bi-menu-button-wide"></i><span>Manajemen Hotel</span><i class="bi bi-chevron-down ms-auto"></i>
                </a>
                <ul id="components-nav" class="nav-content collapse <?= in_array($currentPage, ['kamar', 'staff', 'reports', 'denda']) ? 'show' : '' ?>" data-bs-parent="#sidebar-nav">
                    <li>
                    <?php endif; ?>

            <?php if (hasRole(['Housekeeping'])): ?>
            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'housekeeping' ? '' : 'collapsed' ?>" href="index.php?page=housekeeping">
                    <i class="bi bi-house-fill"></i>
                    <span>Housekeeping</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (hasRole('Manajer')): ?>
                <ul id="components-nav" class="nav-content collapse <?= in_array($currentPage, ['kamar', 'staff', 'reports', 'denda']) ? 'show' : '' ?>" data-bs-parent="#sidebar-nav">
                    <li>
                        <a href="index.php?page=kamar" class="<?= $currentPage === 'kamar' ? 'active' : '' ?>">
                            <i class="bi bi-circle"></i><span>Kamar</span>
                        </a>
                    </li>
                    <li>
                <a class=" <?= $currentPage === 'staff' ? '' : 'collapsed' ?>" href="index.php?page=staff">
                    <i class="bi bi-person-badge"></i>
                    <span>Staff</span>
                </a>
            </li>
            

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'reports' ? '' : 'collapsed' ?>" href="index.php?page=reports">
                    <i class="bi bi-bar-chart"></i>
                    <span>Laporan</span>
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-heading">Profil</li>

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'profile' ? '' : 'collapsed' ?>" href="index.php?page=profile">
                    <i class="bi bi-person"></i>
                    <span>Profil Saya</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Keluar</span>
                </a>
            </li>

        </ul>

    </aside><!-- End Sidebar-->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>
                <?php
                switch ($currentPage) {
                    case 'dashboard': echo 'Dashboard'; break;
                    case 'kamar': echo 'Manajemen Kamar'; break;
                    case 'tamu': echo 'Manajemen Tamu'; break;
                    case 'pemesanan': echo 'Pemesanan'; break;
                    case 'denda': echo 'Manajemen Denda'; break;
                    case 'housekeeping': echo 'Housekeeping'; break;
                    case 'staff': echo 'Manajemen Staff'; break;
                    case 'reports': echo 'Laporan & Analisis'; break;
                    case 'profile': echo 'Profil Saya'; break;
                    default: echo 'Hotel Management System'; break;
                }
                ?>
            </h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item active">
                        <?php
                        switch ($currentPage) {
                            case 'dashboard': echo 'Dashboard'; break;
                            case 'kamar': echo 'Kamar'; break;
                            case 'tamu': echo 'Tamu'; break;
                            case 'pemesanan': echo 'Pemesanan'; break;
                            case 'denda': echo 'Denda'; break;
                            case 'housekeeping': echo 'Housekeeping'; break;
                            case 'staff': echo 'Staff'; break;
                            case 'reports': echo 'Reports'; break;
                            case 'profile': echo 'Profile'; break;
                            default: echo $currentPage; break;
                        }
                        ?>
                    </li>
                </ol>
            </nav>
        </div>
<?php else: ?>
    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">
<div class="d-flex align-items-center justify-content-between">
    <a href="index.php" class="logo d-flex align-items-center">
        <svg class="me-2" width="35px" height="35px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-buildings-fill" viewBox="0 0 16 16">
            <path d="M15 .5a.5.5 0 0 0-.724-.447l-8 4A.5.5 0 0 0 6 4.5v3.14L.342 9.526A.5.5 0 0 0 0 10v5.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V14h1v1.5a.5.5 0 0 0 .5.5h3a.5.5 0 0 0 .5-.5zM2 11h1v1H2zm2 0h1v1H4zm-1 2v1H2v-1zm1 0h1v1H4zm9-10v1h-1V3zM8 5h1v1H8zm1 2v1H8V7zM8 9h1v1H8zm2 0h1v1h-1zm-1 2v1H8v-1zm1 0h1v1h-1zm3-2v1h-1V9zm-1 2h1v1h-1zm-2-4h1v1h-1zm3 0v1h-1V7zm-2-2v1h-1V5zm1 0h1v1h-1z"/>
        </svg>
        <span class="d-none d-lg-block">Magelang Hotel</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
</div><!-- End Logo -->


        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

                <li class="nav-item dropdown pe-3">

                    <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
                        <svg width="30px" height="30px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
  <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
</svg><span class="d-none d-md-block dropdown-toggle ps-2"><?= getUserFullName() ?></span>
                    </a><!-- End Profile Image Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
                        <li class="dropdown-header">
                            <h6><?= getUserFullName() ?></h6>
                            <span>Tamu</span>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="index.php?page=guest/profile">
                                <i class="bi bi-person"></i>
                                <span>Profil Saya</span>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li>
                            <a class="dropdown-item d-flex align-items-center" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                                <i class="bi bi-box-arrow-right"></i>
                                <span>Keluar</span>
                            </a>
                        </li>

                    </ul><!-- End Profile Dropdown Items -->
                </li><!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->

    <!-- ======= Sidebar ======= -->
    <aside id="sidebar" class="sidebar">

        <ul class="sidebar-nav" id="sidebar-nav">

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'guest/dashboard' ? '' : 'collapsed' ?>" href="index.php?page=guest/dashboard">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>
            </li><!-- End Dashboard Nav -->

            <li class="nav-heading">Layanan Tamu</li>

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'guest/pemesanan' ? '' : 'collapsed' ?>" href="index.php?page=guest/pemesanan">
                    <i class="bi bi-house-door"></i>
                    <span>Pesan Kamar</span>
                </a>
            </li>

         

            <li class="nav-heading">Profil</li>

            <li class="nav-item">
                <a class="nav-link <?= $currentPage === 'guest/profile' ? '' : 'collapsed' ?>" href="index.php?page=guest/profile">
                    <i class="bi bi-person"></i>
                    <span>Profil Saya</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-bs-toggle="modal" data-bs-target="#logoutModal">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Keluar</span>
                </a>
            </li>

        </ul>

    </aside><!-- End Sidebar-->

    <main id="main" class="main">
        <div class="pagetitle">
            <h1>
                <?php
                switch ($currentPage) {
                    case 'guest/dashboard': echo 'Dashboard'; break;
                    case 'guest/pemesanan': echo 'Pesan Kamar'; break;
                    case 'guest/bookings': echo 'Pemesanan Saya'; break;
                    case 'guest/profile': echo 'Profil Saya'; break;
                    default: echo 'Portal Tamu'; break;
                }
                ?>
            </h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Beranda</a></li>
                    <li class="breadcrumb-item active">
                        <?php
                        switch ($currentPage) {
                            case 'guest/dashboard': echo 'Dashboard'; break;
                            case 'guest/pemesanan': echo 'Pesan Kamar'; break;
                            case 'guest/bookings': echo 'Pemesanan Saya'; break;
                            case 'guest/profile': echo 'Profil'; break;
                            default: echo str_replace('guest/', '', $currentPage); break;
                        }
                        ?>
                    </li>
                </ol>
            </nav>
        </div>
<?php endif; ?>

        <?php
        // Include content based on page parameter
        $filePath = "pages/{$page}.php";
        if (file_exists($filePath)) {
            include $filePath;
        } else {
            echo '<div class="container-fluid">
                    <div class="text-center">
                        <div class="error mx-auto" data-text="404">404</div>
                        <p class="lead text-gray-800 mb-5">Halaman Tidak Ditemukan</p>
                        <p class="text-gray-500 mb-0">Sepertinya Anda menemukan kesalahan dalam sistem...</p>
                        <a href="index.php">&larr; Kembali ke Dashboard</a>
                    </div>
                  </div>';
        }
        ?>
        </div>
    </main><!-- End Main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>Sistem Manajemen Hotel</span></strong> <?= date('Y') ?>. Hak Cipta Dilindungi
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Siap untuk Keluar?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Pilih "Keluar" di bawah jika Anda siap untuk mengakhiri sesi Anda saat ini.
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Batal</button>
                    <a class="btn btn-primary" href="logout.php">Keluar</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor JS Files -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Core plugin JavaScript-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    
    <!-- Page level plugins -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js"></script>
    
    <!-- Template Main JS File -->
    <script src="assets/js/main.js"></script>
    
    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('.dataTable').DataTable();
            
            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Toggle the side navigation
            document.querySelector('.toggle-sidebar-btn').addEventListener('click', function() {
                document.body.classList.toggle('toggle-sidebar');
            });
        });
    </script>
</body>
</html>
