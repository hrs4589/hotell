<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole(['Manajer','Resepsionis'])) {
    echo '<div class="container-fluid"><div class="alert alert-danger">Anda tidak memiliki izin untuk mengakses halaman ini.</div></div>';
    exit;
}

// Get database connection
global $pdo;

// Process form submissions (only for Manajer)
$success = $error = '';

if (hasRole(['Manajer'])) {
    // Process add/edit room
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        $action = $_POST['action'];
        
        // Common form data
        $nomor_kamar = sanitize($_POST['nomor_kamar']);
        $tipe = sanitize($_POST['tipe']);
        $harga_per_malam = sanitize($_POST['harga_per_malam']);
        $status = sanitize($_POST['status']);
        $fasilitas = sanitize($_POST['fasilitas']);
        $kapasitas = (int)sanitize($_POST['kapasitas']);
        
        // Get note only if status is Maintenance, otherwise set to empty
        $note = ($status === 'Maintenance' && isset($_POST['note'])) ? sanitize($_POST['note']) : '';
        
        // Validate form data
        if (empty($nomor_kamar) || empty($tipe) || empty($harga_per_malam) || empty($kapasitas)) {
            $error = 'Nomor kamar, tipe, harga per malam, dan kapasitas harus diisi';
        } else {
            try {
                // Handle room image upload
                $foto_kamar = '';
                if (isset($_FILES['foto_kamar']) && $_FILES['foto_kamar']['error'] !== UPLOAD_ERR_NO_FILE) {
                    $foto_kamar = uploadFile($_FILES['foto_kamar'], 'rooms');
                    if ($foto_kamar === false) {
                        $error = 'Failed to upload room image. Please check file type and size.';
                    }
                }
                
                if (empty($error)) {
                    if ($action === 'add') {
                        // Check if room number already exists
                        $stmt = $pdo->prepare("SELECT COUNT(*) FROM kamar WHERE nomor_kamar = ?");
                        $stmt->execute([$nomor_kamar]);
                        if ($stmt->fetchColumn() > 0) {
                            $error = 'Room number already exists';
                        } else {
                            // Insert new room
                            $stmt = $pdo->prepare("
                                INSERT INTO kamar (nomor_kamar, tipe, harga_per_malam, status, fasilitas, foto_kamar, note, kapasitas)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([$nomor_kamar, $tipe, $harga_per_malam, $status, $fasilitas, $foto_kamar, $note, $kapasitas]);
                            $success = 'Room added successfully';
                        }
                    } elseif ($action === 'edit' && isset($_POST['id_kamar'])) {
                        $id_kamar = (int)$_POST['id_kamar'];
                        
                        // Check if room exists
                        $stmt = $pdo->prepare("SELECT * FROM kamar WHERE id_kamar = ?");
                        $stmt->execute([$id_kamar]);
                        $room = $stmt->fetch();
                        
                        if (!$room) {
                            $error = 'Room not found';
                        } else {
                            // Check if room number already exists for another room
                            $stmt = $pdo->prepare("SELECT COUNT(*) FROM kamar WHERE nomor_kamar = ? AND id_kamar != ?");
                            $stmt->execute([$nomor_kamar, $id_kamar]);
                            if ($stmt->fetchColumn() > 0) {
                                $error = 'Room number already exists';
                            } else {
                                // If no new photo uploaded, keep the existing one
                                if (empty($foto_kamar)) {
                                    $foto_kamar = $room['foto_kamar'];
                                }
                                
                                // Update room data
                                $stmt = $pdo->prepare("
                                    UPDATE kamar 
                                    SET nomor_kamar = ?, tipe = ?, harga_per_malam = ?, status = ?, fasilitas = ?, foto_kamar = ?, note = ?, kapasitas = ?
                                    WHERE id_kamar = ?
                                ");
                                $stmt->execute([$nomor_kamar, $tipe, $harga_per_malam, $status, $fasilitas, $foto_kamar, $note, $kapasitas, $id_kamar]);
                                $success = 'Room updated successfully';
                            }
                        }
                    }
                }
            } catch (PDOException $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }

    // Process delete room
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id_kamar = (int)$_GET['id'];
        
        try {
            // Check if the room can be deleted (not referenced in bookings)
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM pemesanan WHERE id_kamar = ?");
            $stmt->execute([$id_kamar]);
            if ($stmt->fetchColumn() > 0) {
                $error = 'This room cannot be deleted because it has bookings associated with it';
            } else {
                // Delete the room
                $stmt = $pdo->prepare("DELETE FROM kamar WHERE id_kamar = ?");
                $stmt->execute([$id_kamar]);
                $success = 'Room deleted successfully';
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Get all rooms
try {
    $stmt = $pdo->query("SELECT * FROM kamar ORDER BY nomor_kamar");
    $rooms = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $rooms = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Kamar</h1>
        <?php if (hasRole(['Manajer'])): ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addRoomModal">
            <i class="fas fa-plus"></i> Tambah Kamar Baru
        </button>
        <?php endif; ?>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Room List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Daftar Kamar</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Nomor Kamar</th>
                            <th>Tipe</th>
                            <th>Harga per Malam</th>
                            <th>Status</th>
                            <th>Kapasitas</th>
                            <th>Fasilitas</th>
                            <th>Foto</th>
                            <?php if (hasRole(['Manajer'])): ?>
                            <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rooms)): ?>
                        <tr>
                            <td colspan="<?= hasRole(['Manajer']) ? '8' : '7' ?>" class="text-center">Tidak ada kamar ditemukan</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($rooms as $room): ?>
                            <tr>
                                <td><?= $room['nomor_kamar'] ?></td>
                                <td><?= $room['tipe'] ?></td>
                                <td><?= formatCurrency($room['harga_per_malam']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $room['status'] === 'Tersedia' ? 'success' : ($room['status'] === 'Dipesan' ? 'warning' : 'danger') ?>">
                                        <?= $room['status'] ?>
                                    </span>
                                    <?php if ($room['status'] === 'Maintenance' && !empty($room['note'])): ?>
                                    <br><small class="text-muted mt-1"><i class="bi bi-info-circle"></i> <?= htmlspecialchars($room['note']) ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?= $room['kapasitas'] ?> orang</td>
                                <td><?= $room['fasilitas'] ?: 'N/A' ?></td>
                                <td>
                                    <?php if ($room['foto_kamar']): ?>
                                    <img src="uploads/rooms/<?= $room['foto_kamar'] ?>" alt="Foto Kamar" width="50" height="50" class="img-thumbnail">
                                    <?php else: ?>
                                    <span class="text-muted">Tidak ada foto</span>
                                    <?php endif; ?>
                                </td>
                                <?php if (hasRole(['Manajer'])): ?>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editRoomModal"
                                            data-id="<?= $room['id_kamar'] ?>"
                                            data-nomor="<?= $room['nomor_kamar'] ?>"
                                            data-tipe="<?= $room['tipe'] ?>"
                                            data-harga="<?= $room['harga_per_malam'] ?>"
                                            data-status="<?= $room['status'] ?>"
                                            data-fasilitas="<?= $room['fasilitas'] ?>"
                                            data-foto="<?= $room['foto_kamar'] ?>"
                                            data-note="<?= htmlspecialchars($room['note'] ?? '') ?>"
                                            data-kapasitas="<?= $room['kapasitas'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="index.php?page=kamar&action=delete&id=<?= $room['id_kamar'] ?>" class="btn btn-sm btn-danger btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus kamar ini?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<?php if (hasRole(['Manajer'])): ?>
<!-- Add Room Modal -->
<div class="modal fade" id="addRoomModal" tabindex="-1" aria-labelledby="addRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addRoomModalLabel">Tambah Kamar Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="nomor_kamar" class="form-label">Nomor Kamar</label>
                        <input type="text" class="form-control" id="nomor_kamar" name="nomor_kamar" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="tipe" class="form-label">Tipe Kamar</label>
                        <select class="form-control" id="tipe" name="tipe" required>
                            <?php foreach (getRoomTypes() as $type): ?>
                            <option value="<?= $type ?>"><?= $type ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="harga_per_malam" class="form-label">Harga per Malam</label>
                        <input type="number" class="form-control" id="harga_per_malam" name="harga_per_malam" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="kapasitas" class="form-label">Kapasitas (orang)</label>
                        <input type="number" class="form-control" id="kapasitas" name="kapasitas" min="1" max="10" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-control" id="status" name="status" required onchange="toggleMaintenanceNote(this.value, 'maintenance_note_container')">
                            <?php foreach (getRoomStatuses() as $status): ?>
                            <option value="<?= $status ?>"><?= $status ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="maintenance_note_container" style="display: none;">
                        <label for="note" class="form-label">Catatan Maintenance</label>
                        <textarea class="form-control" id="note" name="note" rows="2" placeholder="Masukkan alasan/detail maintenance"></textarea>
                        <small class="form-text text-muted">Catatan ini akan muncul saat status "Maintenance" dan otomatis dihapus jika status berubah</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="fasilitas" class="form-label">Fasilitas</label>
                        <textarea class="form-control" id="fasilitas" name="fasilitas" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="foto_kamar" class="form-label">Foto Kamar</label>
                        <input type="file" class="form-control" id="foto_kamar" name="foto_kamar" accept="image/*">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Room Modal -->
<div class="modal fade" id="editRoomModal" tabindex="-1" aria-labelledby="editRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editRoomModalLabel">Edit Kamar</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id_kamar" id="edit_id_kamar">
                    
                    <div class="mb-3">
                        <label for="edit_nomor_kamar" class="form-label">Nomor Kamar</label>
                        <input type="text" class="form-control" id="edit_nomor_kamar" name="nomor_kamar" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_tipe" class="form-label">Tipe Kamar</label>
                        <select class="form-control" id="edit_tipe" name="tipe" required>
                            <?php foreach (getRoomTypes() as $type): ?>
                            <option value="<?= $type ?>"><?= $type ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_harga_per_malam" class="form-label">Harga per Malam</label>
                        <input type="number" class="form-control" id="edit_harga_per_malam" name="harga_per_malam" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_kapasitas" class="form-label">Kapasitas (orang)</label>
                        <input type="number" class="form-control" id="edit_kapasitas" name="kapasitas" min="1" max="10" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Status</label>
                        <select class="form-control" id="edit_status" name="status" required onchange="toggleMaintenanceNote(this.value, 'edit_maintenance_note_container')">
                            <?php foreach (getRoomStatuses() as $status): ?>
                            <option value="<?= $status ?>"><?= $status ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3" id="edit_maintenance_note_container" style="display: none;">
                        <label for="edit_note" class="form-label">Catatan Maintenance</label>
                        <textarea class="form-control" id="edit_note" name="note" rows="2" placeholder="Masukkan alasan/detail maintenance"></textarea>
                        <small class="form-text text-muted">Catatan ini akan muncul saat status "Maintenance" dan otomatis dihapus jika status berubah</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_fasilitas" class="form-label">Fasilitas</label>
                        <textarea class="form-control" id="edit_fasilitas" name="fasilitas" rows="3"></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_foto_kamar" class="form-label">Foto Kamar</label>
                        <input type="file" class="form-control" id="edit_foto_kamar" name="foto_kamar" accept="image/*">
                        <small class="form-text text-muted">Biarkan kosong untuk mempertahankan foto saat ini</small>
                        <div id="photo_preview_container" class="mt-2">
                            <img id="photo_preview" class="img-thumbnail" style="max-width: 200px; display: none;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<script>
// Fungsi untuk menampilkan/menyembunyikan field catatan maintenance
function toggleMaintenanceNote(statusValue, containerId) {
    const noteContainer = document.getElementById(containerId);
    if (statusValue === 'Maintenance') {
        noteContainer.style.display = 'block';
        // Jika ini form edit, ambil catatan yang ada via AJAX jika diperlukan
        if (containerId === 'edit_maintenance_note_container') {
            const roomId = document.getElementById('edit_id_kamar').value;
            // Opsional: Anda bisa menambahkan AJAX di sini untuk mengambil catatan saat ini jika diperlukan
        }
    } else {
        noteContainer.style.display = 'none';
        // Jika mengubah dari maintenance ke status lain, kosongkan field catatan
        const noteField = document.getElementById(containerId === 'maintenance_note_container' ? 'note' : 'edit_note');
        if (noteField) {
            noteField.value = '';
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // Menangani klik tombol edit kamar (hanya untuk Manajer)
    <?php if (hasRole(['Manajer'])): ?>
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Ambil data kamar dari atribut tombol
            const roomId = this.dataset.id;
            const roomNumber = this.dataset.nomor;
            const roomType = this.dataset.tipe;
            const roomPrice = this.dataset.harga;
            const roomStatus = this.dataset.status;
            const roomFacilities = this.dataset.fasilitas;
            const roomPhoto = this.dataset.foto;
            const roomNote = this.dataset.note || '';
            const roomCapacity = this.dataset.kapasitas || '2';
            
            // Isi field form dengan data kamar
            document.getElementById('edit_id_kamar').value = roomId;
            document.getElementById('edit_nomor_kamar').value = roomNumber;
            document.getElementById('edit_tipe').value = roomType;
            document.getElementById('edit_harga_per_malam').value = roomPrice;
            document.getElementById('edit_status').value = roomStatus;
            document.getElementById('edit_fasilitas').value = roomFacilities;
            document.getElementById('edit_kapasitas').value = roomCapacity;
            
            // Tampilkan/sembunyikan container catatan maintenance berdasarkan status
            toggleMaintenanceNote(roomStatus, 'edit_maintenance_note_container');
            
            // Set nilai catatan jika status maintenance
            if (roomStatus === 'Maintenance' && document.getElementById('edit_note')) {
                document.getElementById('edit_note').value = roomNote;
            }
            
            // Tampilkan preview foto kamar jika ada
            const photoPreview = document.getElementById('photo_preview');
            if (roomPhoto) {
                photoPreview.src = 'uploads/rooms/' + roomPhoto;
                photoPreview.style.display = 'block';
            } else {
                photoPreview.style.display = 'none';
            }
        });
    });
    <?php endif; ?>
    
    // Periksa nilai status awal untuk menampilkan/menyembunyikan field catatan maintenance
    if (document.getElementById('status')) {
        toggleMaintenanceNote(document.getElementById('status').value, 'maintenance_note_container');
    }
    if (document.getElementById('edit_status')) {
        toggleMaintenanceNote(document.getElementById('edit_status').value, 'edit_maintenance_note_container');
    }
});
</script>