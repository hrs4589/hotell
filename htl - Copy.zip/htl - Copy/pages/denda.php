<?php
// Prevent direct access to this file
if (!defined('DB_HOST')) {
    exit('Direct access denied');
}

// Check if user has permission to access this page
if (!hasRole(['Resepsionis'])) {
    echo '<div class="container-fluid"><div class="alert alert-danger">You do not have permission to access this page.</div></div>';
    exit;
}

// Process form submissions
$success = $error = '';

// Process add/edit penalty
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    // Common form data
    $id_pemesanan = isset($_POST['id_pemesanan']) ? (int)$_POST['id_pemesanan'] : 0;
    $jenis_denda = sanitize($_POST['jenis_denda']);
    $jumlah = isset($_POST['jumlah']) ? (float)$_POST['jumlah'] : 0;
    $status = sanitize($_POST['status']);
    $deskripsi = sanitize($_POST['deskripsi']);
    
    // Validate form data
    if ($id_pemesanan <= 0 || empty($jenis_denda) || $jumlah <= 0) {
        $error = 'Semua data harus diisi dengan lengkap dan valid';
    } else {
        try {
            // Check if booking exists
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM pemesanan WHERE id_pemesanan = ?");
            $stmt->execute([$id_pemesanan]);
            if ($stmt->fetchColumn() == 0) {
                $error = 'Pemesanan tidak ditemukan';
            } else {
                if ($action === 'add') {
                    // Insert new penalty
                    $stmt = $pdo->prepare("
                        INSERT INTO denda (id_pemesanan, jenis_denda, jumlah, status, deskripsi)
                        VALUES (?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$id_pemesanan, $jenis_denda, $jumlah, $status, $deskripsi]);
                    $success = 'Denda berhasil ditambahkan';
                } elseif ($action === 'edit' && isset($_POST['id_denda'])) {
                    $id_denda = (int)$_POST['id_denda'];
                    
                    // Check if penalty exists
                    $stmt = $pdo->prepare("SELECT * FROM denda WHERE id_denda = ?");
                    $stmt->execute([$id_denda]);
                    $penalty = $stmt->fetch();
                    
                    if (!$penalty) {
                        $error = 'Denda tidak ditemukan';
                    } else {
                        // Update penalty data
                        $stmt = $pdo->prepare("
                            UPDATE denda 
                            SET id_pemesanan = ?, jenis_denda = ?, jumlah = ?, status = ?, deskripsi = ?
                            WHERE id_denda = ?
                        ");
                        $stmt->execute([$id_pemesanan, $jenis_denda, $jumlah, $status, $deskripsi, $id_denda]);
                        $success = 'Denda berhasil diperbarui';
                    }
                }
            }
        } catch (PDOException $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Process delete penalty
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id_denda = (int)$_GET['id'];
    
    try {
        // Check if the penalty exists
        $stmt = $pdo->prepare("SELECT * FROM denda WHERE id_denda = ?");
        $stmt->execute([$id_denda]);
        $penalty = $stmt->fetch();
        
        if (!$penalty) {
            $error = 'Denda tidak ditemukan';
        } else {
            // Delete the penalty
            $stmt = $pdo->prepare("DELETE FROM denda WHERE id_denda = ?");
            $stmt->execute([$id_denda]);
            $success = 'Denda berhasil dihapus';
        }
    } catch (PDOException $e) {
        $error = 'Database error: ' . $e->getMessage();
    }
}

// Get all penalties with booking and guest details
try {
    $stmt = $pdo->query("
        SELECT d.*, p.id_pemesanan, p.tanggal_checkin, p.tanggal_checkout, t.nama_lengkap, k.nomor_kamar, k.tipe
        FROM denda d
        JOIN pemesanan p ON d.id_pemesanan = p.id_pemesanan
        JOIN tamu t ON p.id_tamu = t.id_tamu
        JOIN kamar k ON p.id_kamar = k.id_kamar
        ORDER BY d.id_denda DESC
    ");
    $penalties = $stmt->fetchAll();
    
    // Get all bookings for the dropdown
    $stmt = $pdo->query("
        SELECT p.id_pemesanan, p.tanggal_checkin, p.tanggal_checkout, t.nama_lengkap, k.nomor_kamar
        FROM pemesanan p
        JOIN tamu t ON p.id_tamu = t.id_tamu
        JOIN kamar k ON p.id_kamar = k.id_kamar
        ORDER BY p.tanggal_checkin DESC
    ");
    $bookings = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Database error: ' . $e->getMessage();
    $penalties = $bookings = [];
}
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Penalty Management</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPenaltyModal">
            <i class="fas fa-plus"></i> Add New Penalty
        </button>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success">
        <?= $success ?>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-danger">
        <?= $error ?>
    </div>
    <?php endif; ?>

    <!-- Penalty List -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Penalties</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Booking ID</th>
                            <th>Guest</th>
                            <th>Room</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($penalties)): ?>
                        <tr>
                            <td colspan="9" class="text-center">No penalties found</td>
                        </tr>
                        <?php else: ?>
                            <?php foreach ($penalties as $penalty): ?>
                            <tr>
                                <td><?= $penalty['id_denda'] ?></td>
                                <td><?= $penalty['id_pemesanan'] ?></td>
                                <td><?= $penalty['nama_lengkap'] ?></td>
                                <td><?= $penalty['nomor_kamar'] ?> (<?= $penalty['tipe'] ?>)</td>
                                <td><?= $penalty['jenis_denda'] ?></td>
                                <td><?= formatCurrency($penalty['jumlah']) ?></td>
                                <td>
                                    <span class="badge bg-<?= $penalty['status'] === 'Lunas' ? 'success' : 'danger' ?>">
                                        <?= $penalty['status'] ?>
                                    </span>
                                </td>
                                <td><?= $penalty['deskripsi'] ?: 'N/A' ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-primary btn-edit" 
                                            data-bs-toggle="modal" 
                                            data-bs-target="#editPenaltyModal"
                                            data-id="<?= $penalty['id_denda'] ?>"
                                            data-pemesanan="<?= $penalty['id_pemesanan'] ?>"
                                            data-jenis="<?= $penalty['jenis_denda'] ?>"
                                            data-jumlah="<?= $penalty['jumlah'] ?>"
                                            data-status="<?= $penalty['status'] ?>"
                                            data-deskripsi="<?= $penalty['deskripsi'] ?>">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="index.php?page=denda&action=delete&id=<?= $penalty['id_denda'] ?>" class="btn btn-sm btn-danger btn-delete" onclick="return confirm('Are you sure you want to delete this penalty?');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

<!-- Add Penalty Modal -->
<div class="modal fade" id="addPenaltyModal" tabindex="-1" aria-labelledby="addPenaltyModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addPenaltyModalLabel">Add New Penalty</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="id_pemesanan" class="form-label">Booking</label>
                        <select class="form-control" id="id_pemesanan" name="id_pemesanan" required>
                            <option value="">Select Booking</option>
                            <?php foreach ($bookings as $booking): ?>
                            <option value="<?= $booking['id_pemesanan'] ?>">
                                #<?= $booking['id_pemesanan'] ?> - <?= $booking['nama_lengkap'] ?> (Room <?= $booking['nomor_kamar'] ?>) - <?= formatDate($booking['tanggal_checkin']) ?> to <?= formatDate($booking['tanggal_checkout']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="jenis_denda" class="form-label">Penalty Type</label>
                        <input type="text" class="form-control" id="jenis_denda" name="jenis_denda" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Amount</label>
                        <input type="number" class="form-control" id="jumlah" name="jumlah" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-control" id="status" name="status" required>
                            <?php foreach (getPenaltyStatuses() as $status): ?>
                            <option value="<?= $status ?>"><?= $status ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Description</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Penalty Modal -->
<div class="modal fade" id="editPenaltyModal" tabindex="-1" aria-labelledby="editPenaltyModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editPenaltyModalLabel">Edit Penalty</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id_denda" id="edit_id_denda">
                    
                    <div class="mb-3">
                        <label for="edit_id_pemesanan" class="form-label">Booking</label>
                        <select class="form-control" id="edit_id_pemesanan" name="id_pemesanan" required>
                            <option value="">Select Booking</option>
                            <?php foreach ($bookings as $booking): ?>
                            <option value="<?= $booking['id_pemesanan'] ?>">
                                #<?= $booking['id_pemesanan'] ?> - <?= $booking['nama_lengkap'] ?> (Room <?= $booking['nomor_kamar'] ?>) - <?= formatDate($booking['tanggal_checkin']) ?> to <?= formatDate($booking['tanggal_checkout']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_jenis_denda" class="form-label">Penalty Type</label>
                        <input type="text" class="form-control" id="edit_jenis_denda" name="jenis_denda" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_jumlah" class="form-label">Amount</label>
                        <input type="number" class="form-control" id="edit_jumlah" name="jumlah" min="0" step="0.01" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_status" class="form-label">Status</label>
                        <select class="form-control" id="edit_status" name="status" required>
                            <?php foreach (getPenaltyStatuses() as $status): ?>
                            <option value="<?= $status ?>"><?= $status ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_deskripsi" class="form-label">Description</label>
                        <textarea class="form-control" id="edit_deskripsi" name="deskripsi" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle edit penalty button clicks
    const editButtons = document.querySelectorAll('.btn-edit');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Get penalty data from button attributes
            const penaltyId = this.dataset.id;
            const pemesananId = this.dataset.pemesanan;
            const jenisDenda = this.dataset.jenis;
            const jumlah = this.dataset.jumlah;
            const status = this.dataset.status;
            const deskripsi = this.dataset.deskripsi;
            
            // Fill form fields with penalty data
            document.getElementById('edit_id_denda').value = penaltyId;
            document.getElementById('edit_id_pemesanan').value = pemesananId;
            document.getElementById('edit_jenis_denda').value = jenisDenda;
            document.getElementById('edit_jumlah').value = jumlah;
            document.getElementById('edit_status').value = status;
            document.getElementById('edit_deskripsi').value = deskripsi;
        });
    });
});
</script>
